import * as anchor from "@coral-xyz/anchor";

export const NETWORK_CONFIG = {
  // Add any network-specific configuration here
}; 
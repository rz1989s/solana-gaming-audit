curl -X POST https://api.devnet.solana.com -H "Content-Type: application/json" -d '{
"jsonrpc": "2.0",
"id": 1,
"method": "getTransaction",
"params": [
  "5cvTBib4dAKBm7q2SwGzM8AXrKVxWSpu3Wh8v1o8bbxr5XQjLXJUNeZvRb7MZxSPFwX9wwT9iiGggB8Bv7vvn5Xs",
  "json"
]
}'
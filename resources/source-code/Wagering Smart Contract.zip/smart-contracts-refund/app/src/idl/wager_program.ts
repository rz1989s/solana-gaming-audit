export const IDL = {
  // Copy the contents from target/types/wager_program.ts
}; 